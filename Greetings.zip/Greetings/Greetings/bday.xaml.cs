﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace Greetings
{
    public partial class bday : PhoneApplicationPage
    {
        public bday()
        {
            InitializeComponent();
        }

        private void bday1(object sender, System.Windows.Input.GestureEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Birthday1.xaml?target=destination", UriKind.Relative));
        }
    }
}