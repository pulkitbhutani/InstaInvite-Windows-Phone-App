﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Xna.Framework.Media;
using System.Windows.Media.Imaging;
using System.IO;

namespace Greetings
{
    public partial class birth : PhoneApplicationPage
    {
        public birth()
        {
            InitializeComponent();
        }

        private void hello2_GotFocus(object sender, RoutedEventArgs e)
        {
            hello2.Text = "";
        }

        private void number2_GotFocus(object sender, RoutedEventArgs e)
        {
            number2.Text = "";
        }

        private void when2_GotFocus(object sender, RoutedEventArgs e)
        {
            when2.Text = "";
        }

        private void click(object sender, RoutedEventArgs e)
        {

            {
                MediaLibrary library = new MediaLibrary();
                WriteableBitmap bitMap = new WriteableBitmap(canvas1, null);
                MemoryStream ms = new MemoryStream();
                Extensions.SaveJpeg(bitMap, ms, bitMap.PixelWidth,
                                    bitMap.PixelHeight, 0, 100);
                ms.Seek(0, SeekOrigin.Begin);
                library.SavePicture(string.Format("Images\\{0}.jpg",
                                                   Guid.NewGuid()), ms);
            }
        }

        private void cck(object sender, RoutedEventArgs e)
        {
            world.Text = hello2.Text;
            number1.Text = number2.Text;
            when1.Text = when2.Text;
        }
    }
}